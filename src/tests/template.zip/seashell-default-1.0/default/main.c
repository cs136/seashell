/**
 * Welcome to Seashell!
 */

#include <stdio.h>

int main(void) {
	// You can enter your code here.
	printf("Hello World!\n");
}
